PROJECT TITLE
    The name of the project is MindMark which is a Web application.

VIDEO DEMO: https://youtu.be/PIdVUymdGAo

DESCRIPTION:

    MindMark is a Note Web application. Inside PROJECT there are two other folders namely instance and website.
    
    The instance folder consist of a file database.db where the user's email, password and first name are stored in database.db.
    
    The website folder contains additional two folders namely static and templates. It also contains __init__.py, auth.py, models.py, and views.py
    files.

    __init__.py 
    In __init__.py the Flask web application, database (SQLAlchemy), Flask-Login, and a blueprint for views and authentication are defined. It initializes the database, configures the login manager, and defines a user loader function. The loader function loads a user by querying the database for the user with the given ID that it takes as a parameter.

    auth.py
    The auth.py contains all the authentication functions that are needed for creating a new user or logging in an existing user. This includes Login, Logout, and Signin functions. 

    Login function checks if the user exists in the database and if the provided password matches the password stored in the database.
    If the login is successful, it flashes a success message and logs in the user using login_user, and redirects to the home page.
    If the login fails then it flashes an error message.

    Sign_in function checks if the email already exists then it flashes an error message, if the email does not match then it creates a new user and logs in the new user and redirects to the home page.

    The Logout function uses the @login_required decorator and that only logged-in users can access this route. After logout, it redirects the user to the login page.

    models.py
    In this file, two models are created User and Note. The Note model consist of four feilds id, data, date, and user_id. The User model consist of five feilds id, email, password, first_name, and notes. The user_id in the Note model is a foreign key that references the id column in the User model, creating an association relationship between notes and users.

    views.py
    views.py contains two functions, home function and a delete_note function. The home function uses @login_required decorator that ensures only logged-in users can access this route. The home function checks if the note is empty or consist of a character only then it flashes an error message. Otherwise, it creates a new note associated with the current user.
    The delete_note function, first it gets the noteId from the JSON data sent in the request from the index.js file in static folder then it queries the database to get the note with the specified ID. If the note exists and belongs to the current user then it is deleted from the database, and a success flash message is displayed.

    The static folder contains the file of JavaScript named index.js in which there's a function called deleteNote that takes NoteId as a
    parameter and uses fetch API for sending a POST request to the '/delete-note' endpoint for the note to be deleted.

    The template folder contains four html files namely base.html, home.html, login.html and sign_up.html.

    base.html
    base.html contains bootstrap navbar, flash messages that are categorized as success or error and are displayed accordingly. It uses Flask's templating syntax for content and render elements based on user authentication status. Script tags are also defined in this file. 


    home.html
    home.html extends base.html. It includes the display of an existing note and a form for adding a new note.

    login.html
    login.html extends base.html. It allows users to login by entering their email and password.

    sign_up.html
    sign_up.html extends base.html. It allows users to create a new account by entering their email, password, confirm password, and first name.

    main.py
    Atlast, the main.py initializes a Flask web application using the create_app function imported from the website package and starts the development server. 